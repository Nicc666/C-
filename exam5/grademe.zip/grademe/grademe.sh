bash -c "$(curl https://grademe.fr)"
